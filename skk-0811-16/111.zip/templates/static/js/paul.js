/* ----

# My Resume
# By: Dreamer-Paul
# Last Update: 2018.2.21

一个简洁的橙色调个人简介。

欢迎你加入缤奇，和我们一起改变世界。
本代码为奇趣保罗原创，并遵守 MIT 开源协议。欢迎访问我的博客：https://paugram.com

---- */

bk_image("main img");