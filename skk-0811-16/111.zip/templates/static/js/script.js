const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const chatMessages = document.getElementById('chat-messages');
const toggler = document.querySelector(".chatbot-toggler");

sendButton.addEventListener('click', () => {
    const messageText = messageInput.value.trim();

    if (messageText !== '') {
        const inputMessage = createMessage(messageText, 'input-message');
        chatMessages.appendChild(inputMessage);
        // 发送用户输入到后端
        fetch('/process_input', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ input: messageText }),
        })
        .then(response => response.json())
        .then(data => {
            const outputMessage = createMessage(data.output, 'output-message');
            chatMessages.appendChild(outputMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        });

        messageInput.value = '';
    }
});

function createMessage(text, className) {
    const messageDiv = document.createElement('div');
    messageDiv.textContent = text;
    messageDiv.classList.add('message', className);
    return messageDiv;
}
